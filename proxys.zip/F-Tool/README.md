

<h1 align="center">F-Tool - Powerful DDoS Script With 9 Methods</h1>
<em><h5 align="center">Programming Language - Python 3</h5></em>

<p align="center">Please Don't Attack government websites.</p>

# Features And Methods

* Layer4

* VSE: UDP Valve Source Engine specific flood
* SYN: TCP SYN flood
* TCP: TCP junk flood
* UDP:  UDP junk flood
* HTTP: HTTP GET request flood

* Layer7

* SOCKET: Slow HTTP/1.1 socket flood
* HTTP1: TLS HTTP/1.1 GET flood
* HTTP2: TLS HTTP/2 GET flood
* CRINGE: Powerful Method Target Maybe die from Cringe

# Installation

* Please use spoofed server for the best experience.

* ```git clone https://github.com/ngdangtr/F-Tool```
* ```cd F-Tool```
* ```sh install.sh```

* Install CentOS

* ```cd F-Tool; sh installCentOS.sh```



# Contact dev
* Telegram: ```@ngdangtr```

# Donation
* Momo: ```0965849504```




